a=int(input("總秒數為="))
b=int(a/3600)
c=int((a%3600)/60)
d=((a%3600)%60)%60
print(b,"時",c,"分",d,"秒")