a=int(input("請輸入金額(美元)"))
ans=a*30
formatted_ans="{:.2f}".format(ans)
print("相當於",formatted_ans,"新台幣")